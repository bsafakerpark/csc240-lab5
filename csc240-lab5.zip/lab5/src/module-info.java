/**
 * 
 */
/**
 * 
 */
module lab5 {
}