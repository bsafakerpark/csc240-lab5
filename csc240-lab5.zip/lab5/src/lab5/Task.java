package lab5;

public class Task implements Priority{
	
	private String taskName;
    private int priority;

    public Task(String taskName, int prio) {
        this.taskName = taskName;
        setPriority(prio);// Use the setter to enforce priority limits
    }
        
    public void setPriority(int prio) {
        if (prio < 1 || prio > 5) {
            throw new IllegalArgumentException("Priority must be between 1 and 5.");
        }
        this.priority = prio;
    }

    public int getPriority() {
        return priority;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String Name) 
    {
    	this.taskName = Name;
    }
	@Override
	public String toString() {
		return String.format("%-20s %8s %2d %n", taskName, "Priority: ", priority);
	}
    
	
}
