package lab5;

public interface Priority {
	void setPriority(int priority);
    int getPriority();

}

